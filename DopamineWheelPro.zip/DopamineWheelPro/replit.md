# Dopamine Reward Wheel

## Overview

The Dopamine Reward Wheel is a gamified productivity application that motivates users to complete daily tasks by offering randomized rewards through an interactive spinning wheel interface. The application uses a tier-based reward system (common, medium, ultra) with weighted probabilities to create engagement through variable reward mechanics. Built as a client-side web application, it leverages browser localStorage for data persistence and includes features like task tracking, progress monitoring, reward history, confetti animations for positive reinforcement, and a comprehensive admin panel for customization.

**Latest Update (November 10, 2025)**: Fixed critical probability renormalization bug in reward selection logic. The system now correctly handles scenarios where certain reward tiers are locked/unavailable by dynamically renormalizing probabilities to maintain proper weighted distribution.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack**: Vanilla JavaScript, HTML5, and CSS3 with no framework dependencies (except canvas-confetti library for visual effects).

**Rationale**: A framework-free approach was chosen for this simple, self-contained application to minimize complexity and bundle size. This decision keeps the application lightweight and eliminates build tooling requirements while maintaining full control over DOM manipulation and state management.

**Key Components**:
- Canvas-based wheel rendering using HTML5 Canvas API for smooth animations and visual effects
- Custom state management using vanilla JavaScript objects and functions
- Event-driven architecture for user interactions (task completion, wheel spinning)

### Data Storage

**Solution**: Browser localStorage for client-side persistence.

**What's Stored**:
- User rewards configuration (customizable reward list)
- Task completion state (daily task checkboxes)
- Total tasks completed counter (for ultra rare unlock progression)
- Spin history and tracking (has spun today flag, reward history)
- Current rotation state (for wheel animation continuity)

**Rationale**: localStorage provides sufficient persistence for a single-user, browser-based application without requiring backend infrastructure. This approach keeps the application portable and eliminates server costs while meeting the core requirement of preserving user progress between sessions.

**Limitations**: Data is device-specific and browser-specific, with no cross-device synchronization capability.

### Reward System Architecture

**Three-Tier System**:
1. **Common rewards** (60% probability) - Small, immediate gratification (e.g., "30-min break", "Coffee break")
2. **Medium rewards** (30% probability) - Moderate value rewards (e.g., "Movie night", "Order takeout")
3. **Ultra rewards** (10% probability) - High-value rare rewards (e.g., "Weekend trip", "Shopping spree $100")

**Unlock Mechanism**: Ultra rare rewards require completing 5 tasks before they become available, creating a progression system that encourages sustained engagement.

**Design Rationale**: The tiered probability system implements variable ratio reinforcement, a proven behavioral psychology principle that maintains high engagement through unpredictable rewards. The unlock progression adds a secondary goal layer to prevent reward fatigue.

**Probability Renormalization**: When rewards are locked via the admin panel or when ultra rewards are unavailable (total tasks < 5), the selection algorithm dynamically renormalizes probabilities across available tiers only. This ensures weighted distribution remains proportional and prevents undefined reward selection errors.

### Visual Feedback System

**Confetti Animations**: Triggered on reward wins using the canvas-confetti library to provide immediate positive reinforcement.

**Progress Visualization**: Visual progress bar shows advancement toward ultra rare unlock (0/5 tasks completed), creating transparency in progression mechanics.

**Color Coding**: Each tier has distinct visual identity through color (common: green `#00ff88`, medium: gold `#ffd700`, ultra: pink `#ff0080`).

### State Management

**Pattern**: Centralized state object with dedicated load/save functions.

**State Synchronization**: All state mutations trigger localStorage updates to prevent data loss and UI refresh functions to maintain consistency between data and display.

**Daily Reset Logic**: The application tracks "hasSpunToday" to enforce one spin per day, preventing reward exploitation while maintaining daily engagement loop.

### Admin Panel

**Purpose**: Provides comprehensive reward customization without requiring code changes.

**Features**:
- **Manage Rewards**: View all current rewards with tier badges, lock/unlock individual rewards, and delete rewards (minimum 3 required)
- **Add Rewards**: Create new rewards by specifying name and tier (common/medium/ultra)
- **Reset Options**: Reset today's spin (allow re-spinning), clear reward history, or reset all data to defaults
- **Real-time Updates**: All changes immediately affect the wheel rendering and selection logic

**Access**: Fixed position button in bottom-right corner opens modal overlay with all admin controls.

## External Dependencies

### Third-Party Libraries

**canvas-confetti** (v1.6.0)
- **Purpose**: Provides confetti animation effects for reward celebration moments
- **Integration**: Loaded via CDN (jsDelivr)
- **Usage**: Called on successful wheel spin to enhance user experience with visual celebration

### Browser APIs

**localStorage API**
- **Purpose**: Client-side data persistence
- **Storage Schema**: JSON-serialized objects for rewards, task state, and user progress

**Canvas API (HTML5)**
- **Purpose**: Renders the interactive spinning wheel
- **Usage**: Dynamic drawing of wheel segments, rotation animations, and visual effects

**No Backend Services**: The application is entirely self-contained with no server-side dependencies, API calls, or database connections.