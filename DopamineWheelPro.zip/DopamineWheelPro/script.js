// Default tasks configuration
const DEFAULT_TASKS = [
    'Finish work task',
    'Exercise',
    'Read 30 minutes'
];

// Default rewards configuration
const DEFAULT_REWARDS = [
    { name: '30-min break', tier: 'common', locked: false },
    { name: 'Favorite snack', tier: 'common', locked: false },
    { name: 'YouTube video', tier: 'common', locked: false },
    { name: 'Coffee break', tier: 'common', locked: false },
    { name: 'Social media 15min', tier: 'common', locked: false },
    { name: 'Walk outside', tier: 'common', locked: false },
    { name: 'Movie night', tier: 'medium', locked: false },
    { name: 'Order takeout', tier: 'medium', locked: false },
    { name: 'Buy new game', tier: 'medium', locked: false },
    { name: 'Day off tomorrow', tier: 'medium', locked: false },
    { name: 'Shopping spree $100', tier: 'ultra', locked: false },
    { name: 'Weekend trip', tier: 'ultra', locked: false }
];

// Global state
let dailyTasks = [];
let rewards = [];
let totalTasksCompleted = 0;
let hasSpunToday = false;
let rewardHistory = [];
let isSpinning = false;
let currentRotation = 0;

// Tier colors and probabilities
const TIER_COLORS = {
    common: '#00ff88',
    medium: '#ffd700',
    ultra: '#ff0080'
};

const TIER_PROBABILITIES = {
    common: 0.60,
    medium: 0.30,
    ultra: 0.10
};

// Shuffle array function to randomize reward positions
function shuffleArray(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    loadState();
    initializeTaskListeners();
    initializeWheel();
    initializeAdminPanel();
    updateUI();
});

// Load state from localStorage
function loadState() {
    // Load custom tasks
    const savedTasksList = localStorage.getItem('dailyTasksList');
    dailyTasks = savedTasksList ? JSON.parse(savedTasksList) : [...DEFAULT_TASKS];
    
    const savedRewards = localStorage.getItem('rewards');
    const isShuffled = localStorage.getItem('isShuffled');
    
    if (savedRewards) {
        rewards = JSON.parse(savedRewards);
        // If not previously shuffled, shuffle now
        if (!isShuffled) {
            rewards = shuffleArray(rewards);
            localStorage.setItem('isShuffled', 'true');
            saveState();
        }
    } else {
        // First time loading - shuffle the default rewards for random positions on wheel
        rewards = shuffleArray(DEFAULT_REWARDS);
        localStorage.setItem('isShuffled', 'true');
        saveState();
    }
    
    totalTasksCompleted = parseInt(localStorage.getItem('totalTasksCompleted') || '0');
    
    const savedHistory = localStorage.getItem('rewardHistory');
    rewardHistory = savedHistory ? JSON.parse(savedHistory) : [];
    
    // Check if already spun today
    const lastSpinDate = localStorage.getItem('lastSpinDate');
    const today = new Date().toDateString();
    hasSpunToday = (lastSpinDate === today);
    
    // Render tasks dynamically
    renderTasks();
    
    // Load today's task completion status
    const savedTasks = localStorage.getItem('todaysTasks');
    const tasksDate = localStorage.getItem('tasksDate');
    
    if (tasksDate === today && savedTasks) {
        const taskStatus = JSON.parse(savedTasks);
        taskStatus.forEach((completed, index) => {
            const checkbox = document.getElementById(`task${index}`);
            if (checkbox) checkbox.checked = completed;
        });
    } else {
        // Reset tasks for new day
        localStorage.setItem('tasksDate', today);
        saveTasks();
    }
}

// Save state to localStorage
function saveState() {
    localStorage.setItem('dailyTasksList', JSON.stringify(dailyTasks));
    localStorage.setItem('rewards', JSON.stringify(rewards));
    localStorage.setItem('totalTasksCompleted', totalTasksCompleted.toString());
    localStorage.setItem('rewardHistory', JSON.stringify(rewardHistory));
}

function saveTasks() {
    const taskStatus = [];
    dailyTasks.forEach((task, index) => {
        const checkbox = document.getElementById(`task${index}`);
        taskStatus.push(checkbox ? checkbox.checked : false);
    });
    localStorage.setItem('todaysTasks', JSON.stringify(taskStatus));
}

// Render tasks dynamically
function renderTasks() {
    const tasksContainer = document.querySelector('.tasks');
    tasksContainer.innerHTML = '';
    
    dailyTasks.forEach((taskName, index) => {
        const taskHtml = `
            <label class="task-item">
                <input type="checkbox" id="task${index}" data-task="task${index}">
                <span class="checkmark"></span>
                <span class="task-text">${taskName}</span>
            </label>
        `;
        tasksContainer.innerHTML += taskHtml;
    });
    
    // Re-initialize task listeners after rendering
    initializeTaskListeners();
}

// Initialize task checkboxes
function initializeTaskListeners() {
    const checkboxes = document.querySelectorAll('.tasks input[type="checkbox"]');
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', (e) => {
            saveTasks();
            if (e.target.checked) {
                totalTasksCompleted++;
                saveState();
            }
            updateUI();
        });
    });
}

// Update UI based on state
function updateUI() {
    updateProgressBar();
    updateSpinButton();
    updateRewardHistory();
    drawWheel();
}

// Update progress bar
function updateProgressBar() {
    const progress = Math.min((totalTasksCompleted / 5) * 100, 100);
    document.getElementById('progressFill').style.width = `${progress}%`;
    document.getElementById('progressText').textContent = `${totalTasksCompleted}/5 tasks completed`;
}

// Update spin button state
function updateSpinButton() {
    const spinButton = document.getElementById('spinButton');
    const allTasksComplete = Array.from(document.querySelectorAll('.tasks input[type="checkbox"]')).every(cb => cb.checked);
    
    if (hasSpunToday) {
        spinButton.disabled = true;
        spinButton.innerHTML = '✓ Reward Claimed Today';
    } else if (allTasksComplete) {
        spinButton.disabled = false;
        spinButton.innerHTML = 'SPIN THE WHEEL';
    } else {
        spinButton.disabled = true;
        spinButton.innerHTML = '<span class="lock-icon">🔒</span> SPIN THE WHEEL';
    }
}

// Initialize wheel canvas
function initializeWheel() {
    const spinButton = document.getElementById('spinButton');
    spinButton.addEventListener('click', spinWheel);
    drawWheel();
}

// Draw the wheel
function drawWheel() {
    const canvas = document.getElementById('wheelCanvas');
    const ctx = canvas.getContext('2d');
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = 230;
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    const sliceAngle = (2 * Math.PI) / rewards.length;
    const ultraUnlocked = totalTasksCompleted >= 5;
    
    rewards.forEach((reward, index) => {
        const startAngle = index * sliceAngle + currentRotation;
        const endAngle = startAngle + sliceAngle;
        
        // Determine if slice should be greyed out
        const isLocked = reward.tier === 'ultra' && !ultraUnlocked;
        const color = isLocked ? '#333333' : TIER_COLORS[reward.tier];
        
        // Draw slice
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, startAngle, endAngle);
        ctx.lineTo(centerX, centerY);
        ctx.fillStyle = color;
        ctx.fill();
        
        // Add glow effect
        if (!isLocked) {
            ctx.shadowBlur = 20;
            ctx.shadowColor = color;
            ctx.fill();
            ctx.shadowBlur = 0;
        }
        
        // Draw border
        ctx.strokeStyle = '#000';
        ctx.lineWidth = 2;
        ctx.stroke();
        
        // Draw text
        ctx.save();
        ctx.translate(centerX, centerY);
        ctx.rotate(startAngle + sliceAngle / 2);
        ctx.textAlign = 'center';
        ctx.fillStyle = isLocked ? '#666666' : '#ffffff';
        ctx.font = 'bold 14px Arial';
        ctx.fillText(reward.name, radius * 0.65, 5);
        
        // Draw lock icon for locked ultra rare
        if (isLocked) {
            ctx.font = '20px Arial';
            ctx.fillText('🔒', radius * 0.65, -15);
        }
        
        ctx.restore();
    });
    
    // Draw center circle
    ctx.beginPath();
    ctx.arc(centerX, centerY, 40, 0, 2 * Math.PI);
    ctx.fillStyle = '#1a1a2e';
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 3;
    ctx.stroke();
    
    // Draw center text
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 16px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('SPIN', centerX, centerY + 5);
}

// Spin the wheel
function spinWheel() {
    if (isSpinning || hasSpunToday) return;
    
    isSpinning = true;
    const spinButton = document.getElementById('spinButton');
    spinButton.disabled = true;
    
    // Select reward based on probability
    const selectedReward = selectReward();
    const selectedIndex = rewards.indexOf(selectedReward);
    const sliceAngle = (2 * Math.PI) / rewards.length;
    
    // Calculate target rotation
    const targetSliceRotation = selectedIndex * sliceAngle;
    const extraSpins = 5 * (2 * Math.PI); // 5 full rotations
    const targetRotation = extraSpins + (2 * Math.PI - targetSliceRotation) + (sliceAngle / 2);
    
    const duration = 5000; // 5 seconds
    const startTime = Date.now();
    const startRotation = currentRotation;
    
    function animate() {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Easing function for smooth deceleration
        const easeOut = 1 - Math.pow(1 - progress, 3);
        currentRotation = startRotation + (targetRotation * easeOut);
        
        drawWheel();
        
        if (progress < 1) {
            requestAnimationFrame(animate);
        } else {
            isSpinning = false;
            showRewardModal(selectedReward);
            
            // Mark as spun today
            hasSpunToday = true;
            const today = new Date().toDateString();
            localStorage.setItem('lastSpinDate', today);
            
            // Add to history
            addToHistory(selectedReward);
            
            updateUI();
        }
    }
    
    animate();
}

// Select reward based on probability
function selectReward() {
    const ultraUnlocked = totalTasksCompleted >= 5;
    
    // Filter available rewards
    let availableRewards = rewards.filter(r => {
        if (r.locked) return false;
        if (r.tier === 'ultra' && !ultraUnlocked) return false;
        return true;
    });
    
    // If no available rewards, return first unlocked reward or first reward
    if (availableRewards.length === 0) {
        const fallback = rewards.find(r => !r.locked) || rewards[0];
        return fallback;
    }
    
    // Count rewards by tier
    const tierCounts = {
        common: availableRewards.filter(r => r.tier === 'common').length,
        medium: availableRewards.filter(r => r.tier === 'medium').length,
        ultra: availableRewards.filter(r => r.tier === 'ultra').length
    };
    
    // Build renormalized probabilities for available tiers only
    let availableTiers = [];
    let totalProbability = 0;
    
    for (const tier in TIER_PROBABILITIES) {
        if (tierCounts[tier] > 0) {
            availableTiers.push({
                tier: tier,
                probability: TIER_PROBABILITIES[tier]
            });
            totalProbability += TIER_PROBABILITIES[tier];
        }
    }
    
    // If no available tiers (shouldn't happen due to earlier check), return first available
    if (availableTiers.length === 0) {
        return availableRewards[0];
    }
    
    // Renormalize probabilities so they sum to 1.0
    availableTiers.forEach(t => {
        t.normalizedProbability = t.probability / totalProbability;
    });
    
    // Select tier based on renormalized probabilities
    const random = Math.random();
    let cumulative = 0;
    let selectedTier = null;
    
    for (const tierData of availableTiers) {
        cumulative += tierData.normalizedProbability;
        if (random <= cumulative) {
            selectedTier = tierData.tier;
            break;
        }
    }
    
    // Fallback to first available tier if none selected (edge case)
    if (!selectedTier) {
        selectedTier = availableTiers[0].tier;
    }
    
    // Select random reward from tier
    const tierRewards = availableRewards.filter(r => r.tier === selectedTier);
    
    // Defensive check: if tierRewards is empty, return first available reward
    if (tierRewards.length === 0) {
        return availableRewards[0];
    }
    
    const selectedReward = tierRewards[Math.floor(Math.random() * tierRewards.length)];
    
    // Log probability info for verification
    console.log('🎲 Probability Check:', {
        'Selected Tier': selectedTier.toUpperCase(),
        'Tier Probability': (TIER_PROBABILITIES[selectedTier] * 100) + '%',
        'Available Tiers': availableTiers.map(t => 
            `${t.tier.toUpperCase()} (${(t.normalizedProbability * 100).toFixed(1)}%)`
        ).join(', '),
        'Selected Reward': selectedReward.name
    });
    
    return selectedReward;
}

// Show reward modal with confetti
function showRewardModal(reward) {
    const modal = document.getElementById('rewardModal');
    const rewardName = document.getElementById('rewardName');
    const rewardTier = document.getElementById('rewardTier');
    const content = modal.querySelector('.reward-content');
    
    rewardName.textContent = reward.name;
    rewardTier.textContent = reward.tier.toUpperCase();
    rewardTier.className = 'reward-tier tier-' + reward.tier;
    content.style.borderColor = TIER_COLORS[reward.tier];
    
    modal.classList.add('active');
    
    // Trigger confetti
    const duration = 3000;
    const end = Date.now() + duration;
    
    (function frame() {
        confetti({
            particleCount: 7,
            angle: 60,
            spread: 55,
            origin: { x: 0 },
            colors: [TIER_COLORS[reward.tier], '#ffffff', '#ff00ff']
        });
        confetti({
            particleCount: 7,
            angle: 120,
            spread: 55,
            origin: { x: 1 },
            colors: [TIER_COLORS[reward.tier], '#ffffff', '#00ffff']
        });
        
        if (Date.now() < end) {
            requestAnimationFrame(frame);
        }
    }());
    
    document.getElementById('closeReward').onclick = () => {
        modal.classList.remove('active');
    };
}

// Add reward to history
function addToHistory(reward) {
    const entry = {
        date: new Date().toLocaleDateString(),
        name: reward.name,
        tier: reward.tier
    };
    
    rewardHistory.unshift(entry);
    
    // Keep only last 10 entries
    if (rewardHistory.length > 10) {
        rewardHistory = rewardHistory.slice(0, 10);
    }
    
    saveState();
}

// Update reward history table
function updateRewardHistory() {
    const tbody = document.getElementById('historyBody');
    
    if (rewardHistory.length === 0) {
        tbody.innerHTML = '<tr><td colspan="3" class="no-history">No rewards claimed yet</td></tr>';
        return;
    }
    
    tbody.innerHTML = rewardHistory.map(entry => `
        <tr>
            <td>${entry.date}</td>
            <td>${entry.name}</td>
            <td><span class="tier-badge tier-${entry.tier}">${entry.tier.toUpperCase()}</span></td>
        </tr>
    `).join('');
}

// Initialize admin panel
function initializeAdminPanel() {
    const adminToggle = document.getElementById('adminToggle');
    const adminPanel = document.getElementById('adminPanel');
    const closeAdmin = document.querySelector('.close-admin');
    
    adminToggle.addEventListener('click', () => {
        adminPanel.classList.add('active');
        renderTasksList();
        renderRewardsList();
    });
    
    closeAdmin.addEventListener('click', () => {
        adminPanel.classList.remove('active');
    });
    
    adminPanel.addEventListener('click', (e) => {
        if (e.target === adminPanel) {
            adminPanel.classList.remove('active');
        }
    });
    
    // Add task button
    document.getElementById('addTaskBtn').addEventListener('click', addNewTask);
    
    // Add reward button
    document.getElementById('addRewardBtn').addEventListener('click', addNewReward);
    
    // Shuffle wheel button
    document.getElementById('shuffleWheelBtn').addEventListener('click', shuffleWheel);
    
    // Reset buttons
    document.getElementById('resetTodayBtn').addEventListener('click', resetToday);
    document.getElementById('resetHistoryBtn').addEventListener('click', resetHistory);
    document.getElementById('resetAllBtn').addEventListener('click', resetAll);
}

// Render tasks list in admin panel
function renderTasksList() {
    const container = document.getElementById('tasksList');
    
    container.innerHTML = dailyTasks.map((task, index) => `
        <div class="reward-item">
            <div class="reward-info">
                <span>📋</span>
                <span>${task}</span>
            </div>
            <div class="reward-actions">
                <button class="lock-btn" onclick="editTask(${index})">Edit</button>
                <button class="delete-btn" onclick="deleteTask(${index})">Delete</button>
            </div>
        </div>
    `).join('');
}

// Add new task
function addNewTask() {
    const nameInput = document.getElementById('newTaskName');
    const name = nameInput.value.trim();
    
    if (!name) {
        alert('Please enter a task name!');
        return;
    }
    
    dailyTasks.push(name);
    saveState();
    renderTasksList();
    renderTasks();
    updateUI();
    
    nameInput.value = '';
}

// Edit task
function editTask(index) {
    const newName = prompt('Edit task name:', dailyTasks[index]);
    
    if (newName && newName.trim()) {
        dailyTasks[index] = newName.trim();
        saveState();
        renderTasksList();
        renderTasks();
        updateUI();
    }
}

// Delete task
function deleteTask(index) {
    if (dailyTasks.length <= 1) {
        alert('Must have at least 1 task!');
        return;
    }
    
    if (confirm(`Delete task "${dailyTasks[index]}"?`)) {
        dailyTasks.splice(index, 1);
        saveState();
        renderTasksList();
        renderTasks();
        updateUI();
    }
}

// Render rewards list in admin panel
function renderRewardsList() {
    const container = document.getElementById('rewardsList');
    
    container.innerHTML = rewards.map((reward, index) => `
        <div class="reward-item">
            <div class="reward-info">
                <span class="tier-badge tier-${reward.tier}">${reward.tier.toUpperCase()}</span>
                <span>${reward.name}</span>
                ${reward.locked ? '<span>🔒</span>' : ''}
            </div>
            <div class="reward-actions">
                <button class="${reward.locked ? 'unlock-btn' : 'lock-btn'}" onclick="toggleLock(${index})">
                    ${reward.locked ? 'Unlock' : 'Lock'}
                </button>
                <button class="delete-btn" onclick="deleteReward(${index})">Delete</button>
            </div>
        </div>
    `).join('');
}

// Toggle reward lock
function toggleLock(index) {
    rewards[index].locked = !rewards[index].locked;
    saveState();
    renderRewardsList();
    drawWheel();
}

// Delete reward
function deleteReward(index) {
    if (rewards.length <= 3) {
        alert('Must have at least 3 rewards!');
        return;
    }
    
    if (confirm(`Delete "${rewards[index].name}"?`)) {
        rewards.splice(index, 1);
        saveState();
        renderRewardsList();
        drawWheel();
    }
}

// Add new reward
function addNewReward() {
    const nameInput = document.getElementById('newRewardName');
    const tierSelect = document.getElementById('newRewardTier');
    
    const name = nameInput.value.trim();
    const tier = tierSelect.value;
    
    if (!name) {
        alert('Please enter a reward name!');
        return;
    }
    
    rewards.push({
        name: name,
        tier: tier,
        locked: false
    });
    
    saveState();
    renderRewardsList();
    drawWheel();
    
    nameInput.value = '';
    tierSelect.value = 'common';
}

// Shuffle wheel positions
function shuffleWheel() {
    if (confirm('Shuffle the reward positions on the wheel? This will randomize their placement.')) {
        rewards = shuffleArray(rewards);
        saveState();
        renderRewardsList();
        drawWheel();
        alert('Wheel positions have been shuffled! 🔀');
    }
}

// Reset today's spin
function resetToday() {
    if (confirm('Reset today\'s spin? This will allow you to spin again.')) {
        hasSpunToday = false;
        localStorage.removeItem('lastSpinDate');
        updateUI();
        alert('Today\'s spin has been reset!');
    }
}

// Reset history
function resetHistory() {
    if (confirm('Clear all reward history? This cannot be undone.')) {
        rewardHistory = [];
        saveState();
        updateRewardHistory();
        alert('Reward history cleared!');
    }
}

// Reset all data
function resetAll() {
    if (confirm('Reset ALL data? This will clear tasks, history, and restore default rewards. This cannot be undone!')) {
        localStorage.clear();
        dailyTasks = [...DEFAULT_TASKS];
        rewards = shuffleArray(DEFAULT_REWARDS);
        totalTasksCompleted = 0;
        hasSpunToday = false;
        rewardHistory = [];
        
        localStorage.setItem('isShuffled', 'true');
        saveState();
        const today = new Date().toDateString();
        localStorage.setItem('tasksDate', today);
        
        // Re-render tasks with defaults
        renderTasks();
        saveTasks();
        
        updateUI();
        renderTasksList();
        renderRewardsList();
        alert('All data has been reset!');
    }
}

// Make functions globally accessible for onclick handlers
window.toggleLock = toggleLock;
window.deleteReward = deleteReward;
window.editTask = editTask;
window.deleteTask = deleteTask;
